
# Load necessary libraries
library(readr)
library(dplyr)

# Read the datasets
applicants <- read_csv("path_to_your_file/applicants_dataset.csv")
jobs <- read_csv("path_to_your_file/jobs_dataset.csv")

# Example function to match jobs to applicants
match_jobs_to_applicants <- function(applicant_id) {
  applicant <- applicants %>% filter(Applicant_ID == applicant_id)
  
  matched_jobs <- jobs %>%
    filter(
      Industry == applicant$Industry,
      Required_Qualification == applicant$Qualifications,
      Programming_Languages_Needed %in% applicant$Programming_Languages,
      Years_of_Experience_Needed <= applicant$Years_of_Work_Experience
    ) %>%
    arrange(Years_of_Experience_Needed) %>%
    select(Job_ID, Industry, Required_Qualification, Programming_Languages_Needed, Location)
  
  return(matched_jobs)
}

# Example usage for an applicant with ID 1
matched_jobs_for_applicant_1 <- match_jobs_to_applicants(1)
print(matched_jobs_for_applicant_1)
